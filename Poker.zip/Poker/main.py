from graphics import *
from random import *
from poker import *


def main():
    win = GraphWin("Poker", 800, 800)
    win.setBackground("green")

    Blank(330, 312.5, 455, 487.5, win)

    Slot(30, 600, 155, 775, win) #1
    Slot(180, 600, 305, 775, win) #2
    Slot(330, 600, 455, 775, win) #3
    Slot(480, 600, 605, 775, win) #4
    Slot(630, 600, 755, 775, win) #5

    Blank(30, 25, 155, 200, win)
    Blank(180, 25, 305, 200, win)
    Blank(330, 25, 455, 200, win)
    Blank(480, 25, 605, 200, win)
    Blank(630, 25, 755, 200, win)

    deck = shuffle_deck()
    A, B, C, D, E = deck[:5]
    del deck[:5]
    drawCard(A, 30, 600, 155, 775, win)
    drawCard(B, 180, 600, 305, 775, win)
    drawCard(C, 330, 600, 455, 775, win)
    drawCard(D, 480, 600, 605, 775, win)
    drawCard(E, 630, 600, 755, 775, win)

    redeal = 0
    while redeal != 2:
        select1 = 0
        select2 = 0
        select3 = 0
        select4 = 0
        select5 = 0
        
        
        click = win.getKey()
        while click != "d":
            if click == "1":
                if select1 == 0:
                    hide(30, 600, 155, 775, win)
                    drawCard(A, 30, 570, 155, 745, win)
                    select1 = 1    
                elif select1 == 1:
                    hide(30, 570, 155, 745, win)
                    Slot(30, 600, 155, 775, win)
                    drawCard(A, 30, 600, 155, 775, win) 
                    select1 = 0
            elif click == "2":
                if select2 == 0:
                    hide(180, 600, 305, 775, win)
                    drawCard(B, 180, 570, 305, 745, win)
                    select2 = 1        
                elif select2 == 1:
                    hide(180, 570, 305, 745, win)
                    Slot(180, 600, 305, 775, win)
                    drawCard(B, 180, 600, 305, 775, win) 
                    select2 = 0
            elif click == "3":
                if select3 == 0:
                    hide(330, 600, 455, 775, win)
                    drawCard(C, 330, 570, 455, 745, win)
                    select3 = 1        
                elif select3 == 1:
                    hide(330, 570, 455, 745, win)
                    Slot(330, 600, 455, 775, win)
                    drawCard(C, 330, 600, 455, 775, win) 
                    select3 = 0
            elif click == "4":
                if select4 == 0:
                    hide(480, 600, 605, 775, win)
                    drawCard(D, 480, 570, 605, 745, win)
                    select4 = 1        
                elif select4 == 1:
                    hide(480, 570, 605, 745, win)
                    Slot(480, 600, 605, 775, win)
                    drawCard(D, 480, 600, 605, 775, win) 
                    select4 = 0
            elif click == "5":
                if select5 == 0:
                    hide(630, 600, 755, 775, win)
                    drawCard(E, 630, 570, 755, 745, win)
                    select5 = 1        
                elif select5 == 1:
                    hide(630, 570, 755, 745, win)
                    Slot(630, 600, 755, 775, win)
                    drawCard(E, 630, 600, 755, 775, win) 
                    select5 = 0
            click = win.getKey()
            if click == "d":
                if select1 == 1:
                    hide(30, 570, 155, 745, win)
                    Slot(30, 600, 155, 775, win)
                    A = deck[0]
                    drawCard(A, 30, 600, 155, 775, win)
                    del deck[0]
                if select2 == 1:
                    hide(180, 570, 305, 745, win)
                    Slot(180, 600, 305, 775, win)
                    B = deck[0]
                    drawCard(B, 180, 600, 305, 775, win)
                    del deck[0]
                if select3 == 1:
                    hide(330, 570, 455, 745, win)
                    Slot(330, 600, 455, 775, win)
                    C = deck[0]
                    drawCard(C, 330, 600, 455, 775, win)
                    del deck[0]
                if select4 == 1:
                    hide(480, 570, 605, 745, win)
                    Slot(480, 600, 605, 775, win)
                    D = deck[0]
                    drawCard(D, 480, 600, 605, 775, win)
                    del deck[0]
                if select5 == 1:
                    hide(630, 570, 755, 745, win)
                    Slot(630, 600, 755, 775, win)
                    E = deck[0]
                    drawCard(E, 630, 600, 755, 775, win)
                    del deck[0]
        redeal = redeal + 1

    deck = shuffle_deckCPU()
    preset = random()
    if preset <= 0.4:
        F, G, H, I, J = deck[:5]
        del deck[:5]
        drawCard(F, 30, 25, 155, 200, win)
        drawCard(G, 180, 25, 305, 200, win)
        drawCard(H, 330, 25, 455, 200, win)
        drawCard(I, 480, 25, 605, 200, win)
        drawCard(J, 630, 25, 755, 200, win)
    elif preset > 0.4 and preset <= 0.5:
        F, H, G, J = randTwoPair()
        I = "H2"
        drawCard(F, 30, 25, 155, 200, win)
        drawCard(G, 180, 25, 305, 200, win)
        drawCard(H, 330, 25, 455, 200, win)
        drawCard(I, 480, 25, 605, 200, win)
        drawCard(J, 630, 25, 755, 200, win)
    elif preset > 0.5 and preset <= 0.6:
        F, G, H, I, J = randThreeofaHouse()
        drawCard(F, 30, 25, 155, 200, win)
        drawCard(G, 180, 25, 305, 200, win)
        drawCard(H, 330, 25, 455, 200, win)
        drawCard(I, 480, 25, 605, 200, win)
        drawCard(J, 630, 25, 755, 200, win)
    elif preset > 0.6 and preset <= 0.65:
        F, G, H, I, J = randFlush()
        drawCard(F, 30, 25, 155, 200, win)
        drawCard(G, 180, 25, 305, 200, win)
        drawCard(H, 330, 25, 455, 200, win)
        drawCard(I, 480, 25, 605, 200, win)
        drawCard(J, 630, 25, 755, 200, win)
    elif preset > 0.65 and preset <= 0.7:
        F, G, H, I, J = randStraight()
        drawCard(F, 30, 25, 155, 200, win)
        drawCard(G, 180, 25, 305, 200, win)
        drawCard(H, 330, 25, 455, 200, win)
        drawCard(I, 480, 25, 605, 200, win)
        drawCard(J, 630, 25, 755, 200, win)
    elif preset > 0.7 and preset <= 0.72:
        F, G, H, I, J = randFourofaKind()
        drawCard(F, 30, 25, 155, 200, win)
        drawCard(G, 180, 25, 305, 200, win)
        drawCard(H, 330, 25, 455, 200, win)
        drawCard(I, 480, 25, 605, 200, win)
        drawCard(J, 630, 25, 755, 200, win)
    else:
        F, G, H, I, J = deck[:5]
        del deck[:5]
        drawCard(F, 30, 25, 155, 200, win)
        drawCard(G, 180, 25, 305, 200, win)
        drawCard(H, 330, 25, 455, 200, win)
        drawCard(I, 480, 25, 605, 200, win)
        drawCard(J, 630, 25, 755, 200, win)
    
    textp, pointsp = detPoints(A, B, C, D, E)
    textc, pointsc = detPoints(F, G, H, I, J)

    if pointsp > pointsc:
        hand_name = Text(Point(400, 500), textp)
        hand_name.setSize(30)
        hand_name.draw(win)
        hand_name2 = Text(Point(400, 300), textc)
        hand_name2.setSize(30)
        hand_name2.draw(win)
        result = Text(Point(400, 400), "Player Wins!")
        result.setSize(30)
        result.draw(win)
    elif pointsp < pointsc:
        hand_name = Text(Point(400, 500), textp)
        hand_name.setSize(30)
        hand_name.draw(win)
        hand_name2 = Text(Point(400, 300), textc)
        hand_name2.setSize(30)
        hand_name2.draw(win)
        result = Text(Point(400, 400), "Computer Wins!")
        result.setSize(30)
        result.draw(win)
    else:
        hand_name = Text(Point(400, 500), textp)
        hand_name.setSize(30)
        hand_name.draw(win)
        hand_name2 = Text(Point(400, 300), textc)
        hand_name2.setSize(30)
        hand_name2.draw(win)
        result = Text(Point(400, 400), "Tie!")
        result.setSize(30)
        result.draw(win)

    input()
main()