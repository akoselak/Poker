*****************************************
██████╗  ██████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔═══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝██║   ██║██████╚╗█████╗  ██████╔╝
██╔═══╝ ██║   ██║██╔══██║██╔══╝  ██╔══██║ 
██║     ╚██████╔╝██║  ██║███████╗██║  ██║   
╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
*****************************************
By: Aydin Koselak

How to play:
-run main.py in the terminal to start the game
-use the number keys "1, 2, 3, 4, 5" to select and unselect the cards
-press "d" to discard and redraw new card
-you get two discards, use them wisely!
-the game ends and the results show up when you use up your discards
-Have Fun!
