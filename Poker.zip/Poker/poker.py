from math import *
from random import *
from objects import *
def card(H):
    suit, value = list(H)
    if value == "J":
        val1 = 11
    elif value == "Q":
        val1 = 12
    elif value == "K":
        val1 = 13
    elif value == "A":
        val1 = 14
    elif value == "0":
        val1 = 10
    else:
        val1 = int(value)
    if suit == "S":
        val2 = 1
    elif suit == "C":
        val2 = 2
    elif suit == "H":
        val2 = 3
    else:
        val2 = 4
    return val2, val1

def getSuit(H):
   suit, value = card(H)
   return suit

def getValue(H):
   suit, value = card(H)
   return value

def detHighest(A, B, C, D, E):
    if A >= B:
        F = A
    else:
        F = B
    if C >= D:
        G = C
    else:
        G = D
    if F >= G:
        H = F
    else:
        H = G
    if H >= E:
        return H
    else:
        return E

def detLowest(A, B, C, D, E):
    if A <= B:
        F = A
    else:
        F = B
    if C <= D:
        G = C
    else:
        G = D
    if F <= G:
        H = F
    else:
        H = G
    if H <= E:
        return H
    else:
        return E

def Order(A, B, C, D, E):
    F = [A, B, C, D, E]
    F.sort(reverse=True)

    return F

def detStr(A, B, C, D, E):
    F = getValue(A)
    G = getValue(B)
    H = getValue(C)
    I = getValue(D)
    J = getValue(E)
    F, G, H, I, J = Order(F, G, H, I, J)
    if (F - G) == 1:
        if (G - H) == 1:
            if (H - I) == 1:
                if (I - J) == 1:
                    return True

    else:
        return False

def detFlush(A, B, C, D, E):
    if getSuit(A) == getSuit(B) and getSuit(C) == getSuit(D) and getSuit(D) == getSuit(E):
        return True
    else:
        return False
    
def detStrFlush(A, B, C, D, E):
    if detStr(A, B, C, D, E) == True and detFlush(A, B, C, D, E) == True:
        return True
    else:
        return False
    
def detAceStrFlush(A, B, C, D, E):
    if detAceStr(A, B, C, D, E) == True and detFlush(A, B, C, D, E) == True:
        return True
    else:
        return False

def detAceStr(A, B, C, D, E):
    F = getValue(A)
    G = getValue(B)
    H = getValue(C)
    I = getValue(D)
    J = getValue(E)
    if F + G + H + I + J == 28 and F * G * H * I * J == 1680:
        return True
    else:
        return False

def detFourOfKind(A, B, C, D, E):
    F = getValue(A)
    G = getValue(B)
    H = getValue(C)
    I = getValue(D)
    J = getValue(E)
    F, G, H, I, J = Order(F, G, H, I, J)
    if F == G and G == H and H == I:
        return True
    elif G == H and H == I and I == J:
        return True
    else:
        return False

def detFullHouse(A, B, C, D, E):
    F = getValue(A)
    G = getValue(B)
    H = getValue(C)
    I = getValue(D)
    J = getValue(E)
    F, G, H, I, J = Order(F, G, H, I, J)
    if F == G and G == H and I == J and H != I:
        return True
    elif F == G and H == I and I == J and G != H:
        return True
    else:
        return False


def detThreeOfKind(A, B, C, D, E):
    F = getValue(A)
    G = getValue(B)
    H = getValue(C)
    I = getValue(D)
    J = getValue(E)
    F, G, H, I, J = Order(F, G, H, I, J)
    if F == G and G == H:
        return True
    elif G == H and H == I:
        return True
    elif H == I and I == J:
        return True
    else:
        return False
       
def detTwoPair(A, B, C, D, E):
    F = getValue(A)
    G = getValue(B)
    H = getValue(C)
    I = getValue(D)
    J = getValue(E)
    F, G, H, I, J = Order(F, G, H, I, J)
    if F == G and H == I:
        return True
    elif G == H and I == J:
        return True
    elif F == G and I == J:
        return True
    else:
        return False

def detPair(A, B, C, D, E):
    F = getValue(A)
    G = getValue(B)
    H = getValue(C)
    I = getValue(D)
    J = getValue(E)
    F, G, H, I, J = Order(F, G, H, I, J)
    if F == G or G == H or H == I or I == J:
        return True
    else:
        return False
    
def detPoints(A, B, C, D, E):
    if detStrFlush(A, B, C, D, E) == True:
        hand = "Straight Flush"
        points = 900 + detHighest(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
    elif detAceStrFlush(A, B, C, D, E) == True:
        hand = "Straight Flush"
        points = 914
    elif detFourOfKind(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Four of a Kind"
        if A == B and B == C and D != E:
            points = 800 + A
        else:
            points = 800 + B 
    elif detFullHouse(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Full House"
        if A == B and B == C:
            points = 700 + A
        else:
            points = 700 + C
    elif detFlush(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Flush"
        points = 600 + detHighest(A, B, C, D, E)
    elif detStr(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Straight" 
        points = 500 + detHighest(A, B, C, D, E)
    elif detAceStr(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Straight"
        points = 505
    elif detThreeOfKind(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Three of a Kind"
        if A == B and B == C and C != D:
            points = 400 + A
        elif B == C and C == D and D != E and A != B:
            points = 400 + B
        elif C == D and D == E and B != C:
            points = 400 + C
    elif detTwoPair(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Two Pair"
        print(A, B, C, D, E)
        if A == B and C == D and A > C:
            points = 300 + A
        elif A == B and C == D and A < C:
            points = 300 + C
        if A == B and D == E and A > D:
            print("B")
            points = 300 + A
        elif A == B and D == E and A < D:
            points = 300 + D
        if B == C and D == E and C > D:
            print("C")
            points = 300 + C
        elif B == C and D == E and C < D:
            points = 300 + D
    elif detPair(A, B, C, D, E) == True:
        A, B, C, D, E = Order(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
        hand = "Pair"
        if A == B:
            points = 200 + A
        if B == C:
            points = 200 + B
        if C == D:
            points = 200 + C
        if D == E:
            points = 200 + D
    else:
        hand = "High Card"
        points = 100 + detHighest(getValue(A), getValue(B), getValue(C), getValue(D), getValue(E))
    return hand, points

def shuffle_deck():
    deck = [
        "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S0", "SJ", "SQ", "SK", "SA",
        "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C0", "CJ", "CQ", "CK", "CA",
        "H2", "H3", "H4", "H5", "H6", "H7", "H8", "H9", "H0", "HJ", "HQ", "HK", "HA",
        "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D0", "DJ", "DQ", "DK", "DA"
    ]
    shuffle(deck)
    return deck

def shuffle_deckCPU():
    deck = [
        "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S0", "SJ", "SQ", "SK", "SA",
        "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C0", "CJ", "CQ", "CK", "CA",
        "H2", "H3", "H4", "H5", "H6", "H7", "H8", "H9", "H0", "HJ", "HQ", "HK", "HA",
        "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D0", "DJ", "DQ", "DK", "DA"
    ]
    shuffle(deck)
    return deck

def drawCard(C, x1, y1, x2, y2, win):
    if C == "S2": 
        S2(x1, y1, x2, y2, win)
    elif C == "S3":
        S3(x1, y1, x2, y2, win)
    elif C == "S4":
        S4(x1, y1, x2, y2, win)
    elif C == "S5":
        S5(x1, y1, x2, y2, win)
    elif C == "S6":
        S6(x1, y1, x2, y2, win)
    elif C == "S7":
        S7(x1, y1, x2, y2, win)
    elif C == "S8":
        S8(x1, y1, x2, y2, win)
    elif C == "S9":
        S9(x1, y1, x2, y2, win)
    elif C == "S0":
        S0(x1, y1, x2, y2, win)
    elif C == "SJ":
        SJ(x1, y1, x2, y2, win)
    elif C == "SQ":
        SQ(x1, y1, x2, y2, win)
    elif C == "SK":
        SK(x1, y1, x2, y2, win)
    elif C == "SA":
        SA(x1, y1, x2, y2, win)
    elif C == "C2":
        C2(x1, y1, x2, y2, win)
    elif C == "C3":
        C3(x1, y1, x2, y2, win)
    elif C == "C4":
        C4(x1, y1, x2, y2, win)
    elif C == "C5":
        C5(x1, y1, x2, y2, win)
    elif C == "C6":
        C6(x1, y1, x2, y2, win)
    elif C == "C7":
        C7(x1, y1, x2, y2, win)
    elif C == "C8":
        C8(x1, y1, x2, y2, win)
    elif C == "C9":
        C9(x1, y1, x2, y2, win)
    elif C == "C0":
        C0(x1, y1, x2, y2, win)
    elif C == "CJ":
        CJ(x1, y1, x2, y2, win)
    elif C == "CQ":
        CQ(x1, y1, x2, y2, win)
    elif C == "CK":
        CK(x1, y1, x2, y2, win)
    elif C == "CA":
        CA(x1, y1, x2, y2, win)
    elif C == "H2":
        H2(x1, y1, x2, y2, win)
    elif C == "H3":
        H3(x1, y1, x2, y2, win)
    elif C == "H4":
        H4(x1, y1, x2, y2, win)
    elif C == "H5":
        H5(x1, y1, x2, y2, win)
    elif C == "H6":
        H6(x1, y1, x2, y2, win)
    elif C == "H7":
        H7(x1, y1, x2, y2, win)
    elif C == "H8":
        H8(x1, y1, x2, y2, win)
    elif C == "H9":
        H9(x1, y1, x2, y2, win)
    elif C == "H0":
        H0(x1, y1, x2, y2, win)
    elif C == "HJ":
        HJ(x1, y1, x2, y2, win)
    elif C == "HQ":
        HQ(x1, y1, x2, y2, win)
    elif C == "HK":
        HK(x1, y1, x2, y2, win)
    elif C == "HA":
        HA(x1, y1, x2, y2, win)
    elif C == "D2":
        D2(x1, y1, x2, y2, win)
    elif C == "D3":
        D3(x1, y1, x2, y2, win)
    elif C == "D4":
        D4(x1, y1, x2, y2, win)
    elif C == "D5":
        D5(x1, y1, x2, y2, win)
    elif C == "D6":
        D6(x1, y1, x2, y2, win)
    elif C == "D7":
        D7(x1, y1, x2, y2, win)
    elif C == "D8":
        D8(x1, y1, x2, y2, win)
    elif C == "D9":
        D9(x1, y1, x2, y2, win)
    elif C == "D0":
        D0(x1, y1, x2, y2, win)
    elif C == "DJ":
        DJ(x1, y1, x2, y2, win)
    elif C == "DQ":
        DQ(x1, y1, x2, y2, win)
    elif C == "DK":
        DK(x1, y1, x2, y2, win)
    elif C == "DA":
        DA(x1, y1, x2, y2, win)
    else:
        print("ERROR INVALID CARD")

def randPair():
    sdeck = [ 
        "S3", "C3", "S7", "D7",
        "SJ", "HJ", "C6", "D6", "DA", "CA"
    ]
    n = random()
    if n <= 0.25:
        del sdeck[:2]
        x, y = sdeck[:2]
        return x, y
    elif n > 0.25 and n <= 0.5:
        del sdeck[:6]
        x, y = sdeck[:2]
        return x, y
    elif n > 0.5 and n <= 0.6:
        del sdeck[:4]
        x, y = sdeck[:2]
        return x, y
    elif n > 0.6 and n <= 0.7:
        del sdeck[:8]
        x, y = sdeck[:2]
        return x, y
    else:
        x, y = sdeck[:2]
        return x, y

def randTwoPair():
    n = random()
    if n <= 0.25:
        v, w, x, y = "C7", "H7", "S4", "C4"
        return v, w, x, y
    elif n > 0.25 and n <= 0.5:
        v, w, x, y = "S5", "C5", "H6", "S6"
        return v, w, x, y
    elif n > 0.5 and n <= 0.75:
        v, w, x, y = "SQ", "HQ", "H0", "D0"
        return v, w, x, y
    else:
        v, w, x, y = "D0", "C0", "D8", "H8"
        return v, w, x, y

def randThreeofaHouse():
    n = random()
    if n <= 0.2:
        v, w, x, y, z = "H6", "C6", "H5", "D4", "D6"
        return v, w, x, y, z
    elif n > 0.2 and n <= 0.25:
        v, w, x, y, z = "H6", "C4", "S6", "D4", "C6"
        return v, w, x, y, z
    elif n > 0.25 and n <= 0.4:
        v, w, x, y, z = "C9", "D7", "D9", "H9", "DJ"
        return v, w, x, y, z
    elif n > 0.4 and n <= 0.45:
        v, w, x, y, z = "C9", "D9", "CJ", "H9", "DJ"
        return v, w, x, y, z
    elif n > 0.45 and n <= 0.48:
        v, w, x, y, z = "CA", "SA", "CK", "HA", "DK"
        return v, w, x, y, z
    elif n > 0.48:
        v, w, x, y, z = "DJ", "DQ", "CQ", "S0", "SQ"
        return v, w, x, y, z

def randFlush():
    n = random()
    sdeck = ["S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S0", "SJ", "SQ", "SK", "SA"]
    hdeck = ["H2", "H3", "H4", "H5", "H6", "H7", "H8", "H9", "H0", "HJ", "HQ", "HK", "HA"]
    shuffle(sdeck)
    shuffle(hdeck)
    if n <= 0.5:
        A, B, C, D, E = sdeck[:5]
        return A, B, C, D, E
    else:
        A, B, C, D, E = hdeck[:5]
        return A, B, C, D, E
    
def randStraight():
    n = random()
    if n <= 0.25:
        v, w, x, y, z = "SA", "C5", "C4", "D2", "S3"
        return v, w, x, y, z
    elif n > 0.25 and n <= 0.5:
        v, w, x, y, z = "S4", "H5", "H8", "D7", "D6"
        return v, w, x, y, z
    elif n > 0.5 and n <= 0.75:
        v, w, x, y, z = "SQ", "HK", "C0", "D9", "HJ"
        return v, w, x, y, z
    elif n > 0.75 and n <=0.96:
        v, w, x, y, z = "D0", "S9", "D8", "H6", "S7"
        return v, w, x, y, z
    else:
        v, w, x, y, z = "D0", "D9", "D7", "D6", "D8"
        return v, w, x, y, z

def randFourofaKind():
    n = random()
    if n <= 0.33:
        v, w, x, y, z = "SA", "CA", "DA", "HA", "S7"
        return v, w, x, y, z
    elif n > 0.33 and n <= 0.66:
        v, w, x, y, z = "S4", "H5", "H4", "D4", "C4"
        return v, w, x, y, z
    else:
        v, w, x, y, z = "SQ", "HK", "CK", "DK", "SK"
        return v, w, x, y, z