*****************************************
██████╗  ██████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔═══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝██║   ██║██████╚╗█████╗  ██████╔╝
██╔═══╝ ██║   ██║██╔══██║██╔══╝  ██╔══██║ 
██║     ╚██████╔╝██║  ██║███████╗██║  ██║   
╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
*****************************************
By: Aydin Koselak

To start the program, run main.py in the terminal

How to play:
-use the number keys "1, 2, 3, 4, 5" to select and unselect the cards
-press "d" to discard selected cards and redraw new cards
-you get two discards, use them wisely!
-the game ends and the results show up when you use up all of your discards
-Have Fun!

Order of hands:
-Straight Flush
-Four of a Kind
-Full House
-Flush
-Straight
-Three of a Kind
-Two Pair
-Pair
-High Card
