from graphics import *
from random import *
from poker import *


def main(color, difficulty):
    win = GraphWin("Poker", 800, 800)
    win.setBackground("green")

    logo(400, 400, win)

    Slot(30, 600, 155, 775, win) #1
    Slot(180, 600, 305, 775, win) #2
    Slot(330, 600, 455, 775, win) #3
    Slot(480, 600, 605, 775, win) #4
    Slot(630, 600, 755, 775, win) #5

    Blank(color, 30, 25, 155, 200, win)
    Blank(color, 180, 25, 305, 200, win)
    Blank(color, 330, 25, 455, 200, win)
    Blank(color, 480, 25, 605, 200, win)
    Blank(color, 630, 25, 755, 200, win)

    deck = shuffle_deck()
    A, B, C, D, E = deck[:5]
    del deck[:5]
    drawCard(A, 30, 600, 155, 775, win)
    drawCard(B, 180, 600, 305, 775, win)
    drawCard(C, 330, 600, 455, 775, win)
    drawCard(D, 480, 600, 605, 775, win)
    drawCard(E, 630, 600, 755, 775, win)

    redeal = 0
    while redeal != 2:
        select1 = 0
        select2 = 0
        select3 = 0
        select4 = 0
        select5 = 0
        
        
        click = win.getKey()
        while click != "d":
            if click == "1":
                if select1 == 0:
                    hide(30, 600, 155, 775, win)
                    drawCard(A, 30, 570, 155, 745, win)
                    select1 = 1    
                elif select1 == 1:
                    hide(30, 570, 155, 745, win)
                    Slot(30, 600, 155, 775, win)
                    drawCard(A, 30, 600, 155, 775, win) 
                    select1 = 0
            elif click == "2":
                if select2 == 0:
                    hide(180, 600, 305, 775, win)
                    drawCard(B, 180, 570, 305, 745, win)
                    select2 = 1        
                elif select2 == 1:
                    hide(180, 570, 305, 745, win)
                    Slot(180, 600, 305, 775, win)
                    drawCard(B, 180, 600, 305, 775, win) 
                    select2 = 0
            elif click == "3":
                if select3 == 0:
                    hide(330, 600, 455, 775, win)
                    drawCard(C, 330, 570, 455, 745, win)
                    select3 = 1        
                elif select3 == 1:
                    hide(330, 570, 455, 745, win)
                    Slot(330, 600, 455, 775, win)
                    drawCard(C, 330, 600, 455, 775, win) 
                    select3 = 0
            elif click == "4":
                if select4 == 0:
                    hide(480, 600, 605, 775, win)
                    drawCard(D, 480, 570, 605, 745, win)
                    select4 = 1        
                elif select4 == 1:
                    hide(480, 570, 605, 745, win)
                    Slot(480, 600, 605, 775, win)
                    drawCard(D, 480, 600, 605, 775, win) 
                    select4 = 0
            elif click == "5":
                if select5 == 0:
                    hide(630, 600, 755, 775, win)
                    drawCard(E, 630, 570, 755, 745, win)
                    select5 = 1        
                elif select5 == 1:
                    hide(630, 570, 755, 745, win)
                    Slot(630, 600, 755, 775, win)
                    drawCard(E, 630, 600, 755, 775, win) 
                    select5 = 0
            click = win.getKey()
            if click == "d":
                if select1 == 1:
                    hide(30, 570, 155, 745, win)
                    Slot(30, 600, 155, 775, win)
                    A = deck[0]
                    drawCard(A, 30, 600, 155, 775, win)
                    del deck[0]
                if select2 == 1:
                    hide(180, 570, 305, 745, win)
                    Slot(180, 600, 305, 775, win)
                    B = deck[0]
                    drawCard(B, 180, 600, 305, 775, win)
                    del deck[0]
                if select3 == 1:
                    hide(330, 570, 455, 745, win)
                    Slot(330, 600, 455, 775, win)
                    C = deck[0]
                    drawCard(C, 330, 600, 455, 775, win)
                    del deck[0]
                if select4 == 1:
                    hide(480, 570, 605, 745, win)
                    Slot(480, 600, 605, 775, win)
                    D = deck[0]
                    drawCard(D, 480, 600, 605, 775, win)
                    del deck[0]
                if select5 == 1:
                    hide(630, 570, 755, 745, win)
                    Slot(630, 600, 755, 775, win)
                    E = deck[0]
                    drawCard(E, 630, 600, 755, 775, win)
                    del deck[0]
        redeal = redeal + 1

    deck = shuffle_deckCPU()
    preset = random()
    if difficulty == 1:
        if preset <= 0.6:
            F, G, H, I, J = deck[:5]
            del deck[:5]
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.6 and preset <= 0.65:
            F, H, G, J = randTwoPair()
            I = "H2"
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.65 and preset <= 0.68:
            F, G, H, I, J = randThreeofaHouse()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.68 and preset <= 0.7:
            F, G, H, I, J = randFlush()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.7 and preset <= 0.72:
            F, G, H, I, J = randStraight()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.72 and preset <= 0.725:
            F, G, H, I, J = randFourofaKind()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        else:
            F, G, H, I, J = deck[:5]
            del deck[:5]
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
    if difficulty == 2:
        if preset <= 0.4:
            F, G, H, I, J = deck[:5]
            del deck[:5]
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.4 and preset <= 0.5:
            F, H, G, J = randTwoPair()
            I = "H2"
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.5 and preset <= 0.55:
            F, G, H, I, J = randThreeofaHouse()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.6 and preset <= 0.65:
            F, G, H, I, J = randFlush()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.65 and preset <= 0.7:
            F, G, H, I, J = randStraight()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.7 and preset <= 0.72:
            F, G, H, I, J = randFourofaKind()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        else:
            F, G, H, I, J = deck[:5]
            del deck[:5]
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
    elif difficulty == 3:
        if preset <= 0.3:
            F, G, H, I, J = deck[:5]
            del deck[:5]
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.3 and preset <= 0.45:
            F, H, G, J = randTwoPair()
            I = "H2"
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.45 and preset <= 0.52:
            F, G, H, I, J = randThreeofaHouse()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.52 and preset <= 0.6:
            F, G, H, I, J = randFlush()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.6 and preset <= 0.7:
            F, G, H, I, J = randStraight()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        elif preset > 0.7 and preset <= 0.75:
            F, G, H, I, J = randFourofaKind()
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
        else:
            F, G, H, I, J = deck[:5]
            del deck[:5]
            drawCard(F, 30, 25, 155, 200, win)
            drawCard(G, 180, 25, 305, 200, win)
            drawCard(H, 330, 25, 455, 200, win)
            drawCard(I, 480, 25, 605, 200, win)
            drawCard(J, 630, 25, 755, 200, win)
    
    textp, pointsp = detPoints(A, B, C, D, E)
    textc, pointsc = detPoints(F, G, H, I, J)

    if pointsp > pointsc:
        box = Rectangle(Point(225, 540), Point(575, 260))
        box.setFill("white")
        box.draw(win)
        hand_name = Text(Point(400, 500), textp)
        hand_name.setSize(30)
        hand_name.draw(win)
        hand_name2 = Text(Point(400, 300), textc)
        hand_name2.setSize(30)
        hand_name2.draw(win)
        result = Text(Point(400, 400), "Player Wins!")
        result.setSize(30)
        result.setTextColor("green")
        result.draw(win)
    elif pointsp < pointsc:
        box = Rectangle(Point(225, 540), Point(575, 260))
        box.setFill("white")
        box.draw(win)
        hand_name = Text(Point(400, 500), textp)
        hand_name.setSize(30)
        hand_name.draw(win)
        hand_name2 = Text(Point(400, 300), textc)
        hand_name2.setSize(30)
        hand_name2.draw(win)
        result = Text(Point(400, 400), "Computer Wins!")
        result.setSize(30)
        result.setTextColor("red")
        result.draw(win)
    else:
        box = Rectangle(Point(225, 540), Point(575, 260))
        box.setFill("white")
        box.draw(win)
        hand_name = Text(Point(400, 500), textp)
        hand_name.setSize(30)
        hand_name.draw(win)
        hand_name2 = Text(Point(400, 300), textc)
        hand_name2.setSize(30)
        hand_name2.draw(win)
        result = Text(Point(400, 400), "Tie!")
        result.setSize(30)
        result.setTextColor("yellow")
        result.draw(win)
    input("Type anything to enter menu: ")
    win.close()

color = "blue"
difficulty = 2
while True:
    print("Welcome to Poker!")
    print()
    print("type 'how to play' to learn the rules of poker. \ntype 'S' to start the game")
    menu = input("or type 'options' to enter the options menu: ")
    if menu == "options":
        print()
        options = input("type 'color' to change the card color or type 'difficulty' to change the difficulty: ")
        if options == "color":
            color = input("Choose a color for your cards, or type 'exit' to exit the options menu: ")
            if color == "exit":
                color = "blue"
                print()
        elif options == "difficulty":
            while True:
                difficulty = int(input("enter a difficulty setting 1-3: "))
                if difficulty < 1 or difficulty > 3:
                    print("INVALID INPUT!")
                    print()
                else:
                    break
        else:
            print()
    if menu == "s" or menu == "S":
            print()
            break
    if menu == "how to play":
        print()
        print()
        tutorial()
        print()
        print()
    else:
        print()
        
x = 0
main(color, difficulty)
while x != "end":
    print()
    x = input("Enter R to continue or type end to exit: ")
    if x == "r" or x == "R":
        main(color, difficulty)
    elif x == "end":
        print()
    else:
        print("INVALID INPUT!")